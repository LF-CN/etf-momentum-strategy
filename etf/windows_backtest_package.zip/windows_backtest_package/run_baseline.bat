@echo off
cd /d %~dp0
call .venv\Scripts\activate.bat
set MPLBACKEND=Agg
python core\run_preset.py presets\baseline.json
pause
