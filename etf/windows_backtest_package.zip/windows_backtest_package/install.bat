@echo off
chcp 65001 >nul
cd /d %~dp0
if not exist .venv (
  py -3 -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt

echo.
echo 安装完成。
echo 运行示例：
echo   run_baseline.bat
echo   run_max_single_weight_3way.bat
echo   run_preset.bat presets\edge_param_scan.json
pause
