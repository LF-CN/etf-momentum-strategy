ETF Windows 回测包

一、用途
这是 Windows 原生版 ETF 回测包。第一次全量部署后，后续只需要更新 presets 目录下的预设文件，或替换个别 core 脚本。

二、首次安装
1. 确认 Windows 已安装 Python 3.11+，并且命令 py 可用
2. 双击 install.bat
3. 等待依赖安装完成

三、常用运行方式
1. 双击 run_baseline.bat
   运行当前基线参数回测 + Train/Test + Walk-Forward

2. 双击 run_max_single_weight_3way.bat
   比较 max_single_weight = 0.30 / 0.35 / 0.40

3. 命令行运行任意预设
   run_preset.bat presets\edge_param_scan.json

四、结果位置
所有结果都会保存到 results 目录：
- xxx_时间戳.json
- xxx_latest.json

五、目录说明
- core\momentum_backtest.py      回测引擎
- core\run_preset.py             通用预设执行器
- etf_data\                      5只ETF历史CSV
- presets\                       回测预设
- results\                       输出结果

六、以后如何更新
以后只需要更新：
1. presets\*.json
2. 必要时替换 core\run_preset.py 或 core\momentum_backtest.py

七、当前包含的预设
- baseline.json
- max_single_weight_3way.json
- edge_param_scan.json

八、建议
后续优先用“预设文件驱动”做参数测试，这样每次不用重打全量包。
