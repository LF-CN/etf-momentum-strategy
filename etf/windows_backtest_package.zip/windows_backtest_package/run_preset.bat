@echo off
chcp 65001 >nul
cd /d %~dp0
call .venv\Scripts\activate.bat
set MPLBACKEND=Agg
if "%~1"=="" (
  echo 用法: run_preset.bat presets\xxx.json
  pause
  exit /b 1
)
python core\run_preset.py %1
pause
